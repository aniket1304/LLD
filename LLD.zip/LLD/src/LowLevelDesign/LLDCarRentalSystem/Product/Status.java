package LowLevelDesign.LLDCarRentalSystem.Product;

public enum Status {

    ACTIVE,
    INACTIVE;
}
